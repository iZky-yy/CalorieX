import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class CustomBottomNavbar extends StatelessWidget {
  final int currentIndex;

  const CustomBottomNavbar({
    super.key,
    required this.currentIndex,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(25),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          navItem(Icons.home, 0),
          navItem(Icons.calendar_today, 1),
          navItem(Icons.fitness_center, 2),
          navItem(Icons.person, 3),
        ],
      ),
    );
  }

  Widget navItem(IconData icon, int index) {
    return Icon(
      icon,
      color: currentIndex == index
          ? AppColors.green
          : Colors.white54,
    );
  }
}